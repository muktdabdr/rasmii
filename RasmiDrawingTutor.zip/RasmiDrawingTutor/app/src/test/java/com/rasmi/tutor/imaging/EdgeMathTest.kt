package com.rasmi.tutor.imaging

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EdgeMathTest {
    private val w = 8
    private val h = 8
    private val step = FloatArray(w * h) { if (it % w < 4) 0f else 255f }

    @Test
    fun sobelDetectsVerticalStep() {
        val m = EdgeMath.sobel(step, w, h)
        assertTrue(m[3 * w + 3] > 0.9f)
        assertEquals(0f, m[3 * w + 1], 0.0001f)
    }

    @Test
    fun cannyFindsStepAndIgnoresFlat() {
        val e = EdgeMath.canny(step, w, h, 0.2f, 0.5f, 1)
        assertTrue(e[3 * w + 3] || e[3 * w + 4])
        assertFalse(e[3 * w + 1])
    }

    @Test
    fun grayOfWhiteIsAbout255() {
        val g = EdgeMath.gray(intArrayOf(0xFFFFFFFF.toInt()))
        assertEquals(255f, g[0], 0.5f)
    }
}
