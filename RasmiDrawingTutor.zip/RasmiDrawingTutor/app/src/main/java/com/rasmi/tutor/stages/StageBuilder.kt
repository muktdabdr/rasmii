package com.rasmi.tutor.stages

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.rasmi.tutor.imaging.EdgeMath
import kotlin.math.ceil

/**
 * المعالجة على الجهاز فقط، بلا إنترنت ولا مفتاح API:
 * شبكة رسم، كشف الوجوه (ML Kit)، حواف Canny نظيفة، وكتل الدرجات الضوئية.
 * فهم الوجوه حقيقي، أما بقية الصور فتعتمد على الخطوط والتباين وليس على معرفة محتواها.
 */
object StageBuilder {

    /** يُستدعى من خيط خلفي. */
    fun build(src: Bitmap, level: Level): List<Stage> {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val gray = EdgeMath.gray(px)
        val s = w + h
        val out = mutableListOf<Stage>()

        val cols = when (level) { Level.BEGINNER -> 4; Level.INTERMEDIATE -> 6; Level.ADVANCED -> 8 }
        out += Stage(
            "شبكة الرسم",
            "ارسم على ورقتك إطارًا بنفس النسبة، وقسّمه إلى $cols أعمدة بخلايا مربعة، وسمّ الأعمدة بالحروف والصفوف بالأرقام. " +
                "ستنقل بعدها ما في كل خلية إلى الخلية المقابلة، وهذا أدق أسلوب للحفاظ على النسب.",
            "قلم رصاص HB، مسطرة", "سهل", gridLayer(w, h, cols)
        )

        val faces = FaceGuide.detect(src)
        if (faces.isNotEmpty()) {
            out += Stage(
                "بناء الوجه",
                "تم اكتشاف ${faces.size} وجه. ارسم البيضاوي، ثم المحور العمودي (المتقطع)، وخط العينين، وقاعدة الأنف، وخط الفم. " +
                    "قارن المسافات بينها قبل رسم أي تفصيلة.",
                "قلم رصاص HB خفيف، ممحاة", "متوسط", FaceGuide.layer(w, h, faces)
            )
        }

        val coarse = EdgeMath.canny(EdgeMath.blur(gray, w, h, 4), w, h, 0.25f, 0.5f, s / 20)
        out += Stage(
            "الأشكال الكبيرة",
            "ارسم الكتل الكبيرة فقط بخطوط مبسطة، دون تفاصيل. قارن موضع كل كتلة بخلايا الشبكة.",
            "قلم رصاص HB", "سهل", linesLayer(coarse, w, h)
        )

        val mid = EdgeMath.canny(EdgeMath.blur(gray, w, h, 2), w, h, 0.18f, 0.4f, s / 40)
        out += Stage(
            "المحيط والأجزاء الرئيسية",
            "ثبّت حدود الأجزاء الرئيسية بخطوط أوضح، وصحّح النسب والمسافات.",
            "قلم رصاص 2B", "متوسط", linesLayer(mid, w, h)
        )

        if (level != Level.BEGINNER) {
            val fine = EdgeMath.canny(EdgeMath.blur(gray, w, h, 1), w, h, 0.12f, 0.3f, s / 80)
            out += Stage(
                "التفاصيل",
                "أضف التفاصيل المتوسطة ثم الدقيقة، من الأكبر إلى الأصغر.",
                "قلم رصاص 2B، ممحاة قابلة للتشكيل", "متوسط إلى صعب", linesLayer(fine, w, h)
            )
        }

        if (level == Level.ADVANCED) {
            out += Stage(
                "كتل الظل والنور",
                "الصورة مقسمة إلى أربع درجات: الأغمق للأفتح. ظلّل الدرجات من الأفتح إلى الأغمق بطبقات متدرجة، واترك الأبيض فارغًا.",
                "أقلام 2B و4B و6B، ممحاة", "صعب", valueLayer(EdgeMath.blur(gray, w, h, 4), w, h)
            )
        }
        return out
    }

    private fun linesLayer(edge: BooleanArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h)
        val c = (0xFF2B2B35).toInt()
        for (y in 0 until h) for (x in 0 until w) {
            if (!edge[y * w + x]) continue
            px[y * w + x] = c
            if (x + 1 < w) px[y * w + x + 1] = c
            if (y + 1 < h) px[(y + 1) * w + x] = c
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** أربع درجات حسب توزيع الإضاءة في الصورة نفسها، فتعمل مع الصور الفاتحة والداكنة. */
    private fun valueLayer(g: FloatArray, w: Int, h: Int): Bitmap {
        val sorted = g.copyOf().also { it.sort() }
        val q1 = sorted[sorted.size / 4]
        val q2 = sorted[sorted.size / 2]
        val q3 = sorted[sorted.size * 3 / 4]
        val px = IntArray(w * h) {
            val a = when {
                g[it] < q1 -> 190
                g[it] < q2 -> 120
                g[it] < q3 -> 55
                else -> 0
            }
            (a shl 24) or 0x101018
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun gridLayer(w: Int, h: Int, cols: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val cell = w / cols.toFloat()
        val rows = ceil(h / cell).toInt()
        val line = Paint().apply {
            color = Color.argb(210, 90, 70, 160)
            strokeWidth = (w / 400f).coerceAtLeast(1.5f)
            style = Paint.Style.STROKE
        }
        val text = Paint().apply {
            color = Color.argb(230, 60, 40, 130)
            textSize = cell * 0.22f
            isAntiAlias = true
        }
        c.drawRect(1f, 1f, w - 1f, h - 1f, line)
        for (i in 1 until cols) c.drawLine(i * cell, 0f, i * cell, h.toFloat(), line)
        for (j in 1..rows) if (j * cell < h) c.drawLine(0f, j * cell, w.toFloat(), j * cell, line)
        for (i in 0 until cols) c.drawText(('A' + i).toString(), i * cell + cell * 0.08f, cell * 0.25f, text)
        for (j in 1 until rows) c.drawText(j.toString(), cell * 0.06f, j * cell + cell * 0.25f, text)
        return bmp
    }
}
