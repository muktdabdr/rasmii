package com.rasmi.tutor.imaging

import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.sqrt

/** خوارزميات صرفة (بدون Android) لسهولة الاختبار. */
object EdgeMath {
    fun gray(px: IntArray): FloatArray = FloatArray(px.size) {
        val c = px[it]
        0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
    }

    fun blur(src: FloatArray, w: Int, h: Int, passes: Int): FloatArray {
        var a = src
        repeat(passes) {
            val o = FloatArray(a.size)
            for (y in 0 until h) for (x in 0 until w) {
                var s = 0f
                for (dy in -1..1) {
                    val yy = (y + dy).coerceIn(0, h - 1)
                    for (dx in -1..1) s += a[yy * w + (x + dx).coerceIn(0, w - 1)]
                }
                o[y * w + x] = s / 9f
            }
            a = o
        }
        return a
    }

    private fun normalize(m: FloatArray) {
        val sorted = m.copyOf().also { it.sort() }
        val p = sorted[(sorted.size * 0.99f).toInt().coerceAtMost(sorted.size - 1)]
        val d = if (p > 1e-3f) p else 1f
        for (i in m.indices) m[i] = (m[i] / d).coerceAtMost(1f)
    }

    /** Sobel؛ الناتج مُطبَّع بحيث المئين 99 = 1. */
    fun sobel(g: FloatArray, w: Int, h: Int): FloatArray {
        val m = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] + g[i - w + 1] - 2 * g[i - 1] + 2 * g[i + 1] - g[i + w - 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            m[i] = sqrt(gx * gx + gy * gy)
        }
        normalize(m)
        return m
    }

    /** Canny: تنحيف الحواف + عتبتان مع تتبع + حذف المقاطع الصغيرة (ضوضاء). */
    fun canny(g: FloatArray, w: Int, h: Int, lowF: Float, highF: Float, minLen: Int): BooleanArray {
        val n = w * h
        val mag = FloatArray(n)
        val dir = ByteArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] + g[i - w + 1] - 2 * g[i - 1] + 2 * g[i + 1] - g[i + w - 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            mag[i] = sqrt(gx * gx + gy * gy)
            var a = (atan2(gy, gx) * 180.0 / PI).toFloat()
            if (a < 0f) a += 180f
            dir[i] = when {
                a < 22.5f || a >= 157.5f -> 0
                a < 67.5f -> 1
                a < 112.5f -> 2
                else -> 3
            }
        }
        normalize(mag)

        val thin = FloatArray(n)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val off = when (dir[i].toInt()) { 0 -> 1; 1 -> w + 1; 2 -> w; else -> w - 1 }
            if (mag[i] >= mag[i - off] && mag[i] >= mag[i + off]) thin[i] = mag[i]
        }

        val edge = BooleanArray(n)
        val stack = IntArray(n)
        var sp = 0
        for (i in 0 until n) if (thin[i] >= highF) { edge[i] = true; stack[sp++] = i }
        while (sp > 0) {
            val i = stack[--sp]
            val x = i % w; val y = i / w
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val xx = x + dx; val yy = y + dy
                if (xx < 0 || xx >= w || yy < 0 || yy >= h) continue
                val j = yy * w + xx
                if (!edge[j] && thin[j] >= lowF) { edge[j] = true; stack[sp++] = j }
            }
        }

        if (minLen > 1) {
            val seen = BooleanArray(n)
            val comp = IntArray(n)
            for (s in 0 until n) {
                if (!edge[s] || seen[s]) continue
                var cnt = 0
                sp = 0; stack[sp++] = s; seen[s] = true
                while (sp > 0) {
                    val i = stack[--sp]
                    comp[cnt++] = i
                    val x = i % w; val y = i / w
                    for (dy in -1..1) for (dx in -1..1) {
                        if (dx == 0 && dy == 0) continue
                        val xx = x + dx; val yy = y + dy
                        if (xx < 0 || xx >= w || yy < 0 || yy >= h) continue
                        val j = yy * w + xx
                        if (edge[j] && !seen[j]) { seen[j] = true; stack[sp++] = j }
                    }
                }
                if (cnt < minLen) for (k in 0 until cnt) edge[comp[k]] = false
            }
        }
        return edge
    }
}
