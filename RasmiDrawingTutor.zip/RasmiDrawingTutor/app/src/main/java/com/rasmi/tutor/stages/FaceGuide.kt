package com.rasmi.tutor.stages

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark

/** كشف الوجوه على الجهاز (ML Kit، بدون إنترنت وبدون مفتاح) ورسم خطوط بناء الوجه. */
object FaceGuide {

    /** يُستدعى من خيط خلفي فقط. */
    fun detect(bmp: Bitmap): List<Face> = try {
        val opts = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .build()
        val det = FaceDetection.getClient(opts)
        val res = Tasks.await(det.process(InputImage.fromBitmap(bmp, 0)))
        det.close()
        res.sortedByDescending { it.boundingBox.width() * it.boundingBox.height() }.take(3)
    } catch (e: Exception) {
        emptyList()
    }

    fun layer(w: Int, h: Int, faces: List<Face>): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply {
            color = Color.rgb(91, 63, 176)
            style = Paint.Style.STROKE
            strokeWidth = (w / 250f).coerceAtLeast(2f)
            isAntiAlias = true
        }
        val dashed = Paint(p).apply { pathEffect = DashPathEffect(floatArrayOf(16f, 12f), 0f) }

        for (f in faces) {
            val bb = f.boundingBox
            val pts = f.getContour(FaceContour.FACE)?.points
            if (pts != null && pts.size > 3) {
                val path = Path()
                path.moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) path.lineTo(pts[i].x, pts[i].y)
                path.close()
                c.drawPath(path, p)
            } else {
                c.drawOval(bb.left.toFloat(), bb.top.toFloat(), bb.right.toFloat(), bb.bottom.toFloat(), p)
            }

            val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
            val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
            if (le != null && re != null) {
                val cx = (le.x + re.x) / 2f
                val ey = (le.y + re.y) / 2f
                c.drawLine(cx, bb.top.toFloat(), cx, bb.bottom.toFloat(), dashed)      // المحور العمودي
                c.drawLine(bb.left.toFloat(), ey, bb.right.toFloat(), ey, dashed)       // خط العينين
                val r = bb.width() * 0.06f
                c.drawCircle(le.x, le.y, r, p)
                c.drawCircle(re.x, re.y, r, p)
                f.getLandmark(FaceLandmark.NOSE_BASE)?.position?.let { n ->
                    val half = bb.width() * 0.18f
                    c.drawLine(cx - half, n.y, cx + half, n.y, p)                        // قاعدة الأنف
                }
            }
            val ml = f.getLandmark(FaceLandmark.MOUTH_LEFT)?.position
            val mr = f.getLandmark(FaceLandmark.MOUTH_RIGHT)?.position
            if (ml != null && mr != null) c.drawLine(ml.x, ml.y, mr.x, mr.y, p)         // خط الفم
        }
        return bmp
    }
}
