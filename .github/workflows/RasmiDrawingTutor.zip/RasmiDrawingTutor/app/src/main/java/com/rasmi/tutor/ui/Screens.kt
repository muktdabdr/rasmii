package com.rasmi.tutor.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rasmi.tutor.imaging.ImageLoader
import com.rasmi.tutor.stages.Level
import com.rasmi.tutor.stages.Stage
import com.rasmi.tutor.stages.StageBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun WelcomeScreen(onStart: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("رسمي", fontSize = 48.sp, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text(
                "حوّل أي صورة إلى دليل رسم تعليمي متدرج.\nالمعالجة تتم على هاتفك دون إرسال صورك لأي خادم.",
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
            Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(56.dp)) { Text("ابدأ") }
        }
    }
}

@Composable
fun HomeScreen(
    bitmap: Bitmap?, level: Level,
    onLevel: (Level) -> Unit, onBitmap: (Bitmap) -> Unit, onAnalyze: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { ImageLoader.load(context.contentResolver, uri) }.getOrNull()
            }
            if (bmp != null) { onBitmap(bmp); error = null } else error = "تعذّر فتح الصورة"
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("اختر صورة", fontSize = 24.sp)
            if (bitmap != null) {
                Image(
                    bitmap.asImageBitmap(), null,
                    Modifier.fillMaxWidth().weight(1f), contentScale = ContentScale.Fit
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("اختيار من المعرض") }

            Text("المستوى")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Level.values().forEach { l ->
                    if (l == level) Button(onClick = { onLevel(l) }, Modifier.weight(1f)) { Text(l.label) }
                    else OutlinedButton(onClick = { onLevel(l) }, Modifier.weight(1f)) { Text(l.label) }
                }
            }
            Button(
                onClick = onAnalyze, enabled = bitmap != null,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("حلّل (محليًا)") }
        }
    }
}

@Composable
fun ProgressScreen(bitmap: Bitmap, level: Level, onDone: (List<Stage>) -> Unit) {
    LaunchedEffect(bitmap, level) {
        val result = withContext(Dispatchers.Default) { StageBuilder.build(bitmap, level) }
        onDone(result)
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("جارٍ التحليل المحلي…")
        }
    }
}
