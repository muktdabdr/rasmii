package com.rasmi.tutor.stages

import android.graphics.Bitmap

enum class Level(val label: String) {
    BEGINNER("مبتدئ"), INTERMEDIATE("متوسط"), ADVANCED("متقدم")
}

/** كل الطبقات بنفس أبعاد الصورة العاملة، فتبقى الإحداثيات ثابتة بين المراحل. */
data class Stage(
    val title: String,
    val instruction: String,
    val tools: String,
    val difficulty: String,
    val layer: Bitmap,
)
