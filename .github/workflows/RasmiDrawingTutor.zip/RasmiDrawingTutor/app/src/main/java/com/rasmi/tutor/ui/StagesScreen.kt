package com.rasmi.tutor.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rasmi.tutor.stages.Stage

@Composable
fun StagesScreen(ref: Bitmap, stages: List<Stage>, onBack: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var refAlpha by remember { mutableFloatStateOf(0.5f) }
    var lineAlpha by remember { mutableFloatStateOf(1f) }
    var showPrev by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val tState = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 5f)
        offset += pan
    }
    val st = stages[idx]

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("المرحلة ${idx + 1} من ${stages.size}: ${st.title}", fontSize = 18.sp)

            Box(
                Modifier.fillMaxWidth()
                    .aspectRatio(ref.width.toFloat() / ref.height)
                    .clipToBounds().background(Color.White).transformable(tState)
            ) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer(
                        scaleX = scale, scaleY = scale,
                        translationX = offset.x, translationY = offset.y
                    )
                ) {
                    Image(ref.asImageBitmap(), null, Modifier.fillMaxSize(), alpha = refAlpha, contentScale = ContentScale.FillBounds)
                    val range = if (showPrev) 0..idx else idx..idx
                    for (i in range) {
                        Image(stages[i].layer.asImageBitmap(), null, Modifier.fillMaxSize(), alpha = lineAlpha, contentScale = ContentScale.FillBounds)
                    }
                }
            }

            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(st.instruction)
                    Text("الأدوات: ${st.tools}")
                    Text("الصعوبة: ${st.difficulty}")
                }
            }

            Text("شفافية الصورة المرجعية")
            Slider(refAlpha, { refAlpha = it })
            Text("شفافية الخطوط")
            Slider(lineAlpha, { lineAlpha = it })
            Row {
                Text("إظهار المراحل السابقة", Modifier.weight(1f))
                Switch(showPrev, { showPrev = it })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ if (idx > 0) idx-- }, Modifier.weight(1f), enabled = idx > 0) { Text("السابق") }
                Button({ if (idx < stages.lastIndex) idx++ }, Modifier.weight(1f), enabled = idx < stages.lastIndex) { Text("التالي") }
            }
            TextButton(onBack) { Text("رجوع") }
        }
    }
}
