package com.rasmi.tutor.imaging

import kotlin.math.sqrt

/** خوارزميات صرفة (بدون Android) لسهولة الاختبار. */
object EdgeMath {
    fun gray(px: IntArray): FloatArray = FloatArray(px.size) {
        val c = px[it]
        0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
    }

    fun blur(src: FloatArray, w: Int, h: Int, passes: Int): FloatArray {
        var a = src
        repeat(passes) {
            val o = FloatArray(a.size)
            for (y in 0 until h) for (x in 0 until w) {
                var s = 0f
                for (dy in -1..1) {
                    val yy = (y + dy).coerceIn(0, h - 1)
                    for (dx in -1..1) s += a[yy * w + (x + dx).coerceIn(0, w - 1)]
                }
                o[y * w + x] = s / 9f
            }
            a = o
        }
        return a
    }

    /** Sobel؛ الناتج مُطبَّع بحيث المئين 99 = 1. */
    fun sobel(g: FloatArray, w: Int, h: Int): FloatArray {
        val m = FloatArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val gx = -g[i - w - 1] + g[i - w + 1] - 2 * g[i - 1] + 2 * g[i + 1] - g[i + w - 1] + g[i + w + 1]
            val gy = -g[i - w - 1] - 2 * g[i - w] - g[i - w + 1] + g[i + w - 1] + 2 * g[i + w] + g[i + w + 1]
            m[i] = sqrt(gx * gx + gy * gy)
        }
        val sorted = m.copyOf().also { it.sort() }
        val p = sorted[(sorted.size * 0.99f).toInt().coerceAtMost(sorted.size - 1)]
        val d = if (p > 1e-3f) p else 1f
        for (i in m.indices) m[i] = (m[i] / d).coerceAtMost(1f)
        return m
    }
}
