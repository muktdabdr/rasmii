package com.rasmi.tutor.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF9B7EDC),
    onPrimary = Color.White,
    secondary = Color(0xFFC0C0C8),
    background = Color(0xFF0B0B10),
    onBackground = Color(0xFFF2F2F5),
    surface = Color(0xFF16161D),
    onSurface = Color(0xFFF2F2F5),
)

@Composable
fun RasmiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
