package com.rasmi.tutor.stages

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import com.rasmi.tutor.imaging.EdgeMath

/**
 * المعالجة المحلية فقط: حواف وتباين، وليست فهمًا دلاليًا للصورة.
 * الفهم الذكي (محاور، نسب، عناصر) يأتي لاحقًا عبر الخادم.
 */
object StageBuilder {

    fun build(src: Bitmap, level: Level): List<Stage> {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val gray = EdgeMath.gray(px)
        val out = mutableListOf<Stage>()

        out += Stage(
            "تكوين الصورة وخطوط البناء",
            "ارسم إطارًا بنفس نسبة الصورة، ثم قسّمه بخطوط الثلث والمحورين الأوسطين بخفة شديدة.",
            "قلم رصاص HB، مسطرة", "سهل", gridLayer(w, h)
        )

        val coarse = EdgeMath.sobel(EdgeMath.blur(gray, w, h, 5), w, h)
        out += Stage(
            "الأشكال الكبيرة",
            "ارسم الكتل الكبيرة فقط بخطوط مبسطة، دون أي تفاصيل. قارن مواضعها بخطوط الشبكة.",
            "قلم رصاص HB", "سهل", linesLayer(coarse, w, h, 0.30f)
        )

        val mid = EdgeMath.sobel(EdgeMath.blur(gray, w, h, 2), w, h)
        out += Stage(
            "المحيط الخارجي",
            "اثبّت حدود الأجزاء الرئيسية بخطوط أوضح، وصحّح النسب والمسافات بين الأجزاء.",
            "قلم رصاص 2B", "متوسط", linesLayer(mid, w, h, 0.22f)
        )

        if (level != Level.BEGINNER) {
            val fine = EdgeMath.sobel(EdgeMath.blur(gray, w, h, 1), w, h)
            out += Stage(
                "التفاصيل",
                "أضف التفاصيل المتوسطة والدقيقة بالترتيب من الأكبر إلى الأصغر.",
                "قلم رصاص 2B، ممحاة قابلة للتشكيل", "متوسط إلى صعب", linesLayer(fine, w, h, 0.12f)
            )
        }

        if (level == Level.ADVANCED) {
            out += Stage(
                "مناطق الظل والنور",
                "حدّد المناطق الداكنة بتظليل خفيف متدرج، واترك الفاتحة بيضاء.",
                "أقلام 4B و6B، ممحاة", "صعب", shadowLayer(EdgeMath.blur(gray, w, h, 3), w, h)
            )
        }
        return out
    }

    private fun linesLayer(mag: FloatArray, w: Int, h: Int, t: Float): Bitmap {
        val px = IntArray(w * h) { if (mag[it] >= t) (0xFF2B2B35).toInt() else 0 }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun shadowLayer(g: FloatArray, w: Int, h: Int): Bitmap {
        val px = IntArray(w * h) {
            when {
                g[it] < 85f -> (150 shl 24) or 0x101018
                g[it] < 170f -> (70 shl 24) or 0x101018
                else -> 0
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun gridLayer(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint().apply {
            color = Color.argb(200, 90, 70, 160)
            strokeWidth = (w / 300f).coerceAtLeast(2f)
            style = Paint.Style.STROKE
        }
        c.drawRect(1f, 1f, w - 1f, h - 1f, p)
        p.pathEffect = DashPathEffect(floatArrayOf(18f, 14f), 0f)
        for (i in 1..2) {
            c.drawLine(w * i / 3f, 0f, w * i / 3f, h.toFloat(), p)
            c.drawLine(0f, h * i / 3f, w.toFloat(), h * i / 3f, p)
        }
        c.drawLine(w / 2f, 0f, w / 2f, h.toFloat(), p)
        c.drawLine(0f, h / 2f, w.toFloat(), h / 2f, p)
        return bmp
    }
}
