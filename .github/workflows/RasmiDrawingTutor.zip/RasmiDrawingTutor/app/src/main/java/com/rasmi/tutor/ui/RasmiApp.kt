package com.rasmi.tutor.ui

import android.graphics.Bitmap
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.rasmi.tutor.stages.Level
import com.rasmi.tutor.stages.Stage

@Composable
fun RasmiApp() {
    val nav = rememberNavController()
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var level by remember { mutableStateOf(Level.ADVANCED) }
    var stages by remember { mutableStateOf<List<Stage>>(emptyList()) }

    NavHost(nav, startDestination = "welcome") {
        composable("welcome") { WelcomeScreen { nav.navigate("home") } }
        composable("home") {
            HomeScreen(
                bitmap = bitmap, level = level,
                onLevel = { level = it },
                onBitmap = { bitmap = it },
                onAnalyze = { nav.navigate("progress") }
            )
        }
        composable("progress") {
            val b = bitmap
            if (b == null) {
                LaunchedEffect(Unit) { nav.popBackStack("home", false) }
            } else {
                ProgressScreen(b, level) { result ->
                    stages = result
                    nav.navigate("stages") { popUpTo("home") }
                }
            }
        }
        composable("stages") {
            val b = bitmap
            if (b == null || stages.isEmpty()) {
                LaunchedEffect(Unit) { nav.popBackStack("home", false) }
            } else {
                StagesScreen(b, stages) { nav.popBackStack() }
            }
        }
    }
}
