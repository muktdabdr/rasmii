package com.rasmi.tutor.imaging

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EdgeMathTest {
    @Test
    fun sobelDetectsVerticalStep() {
        val w = 8; val h = 8
        val g = FloatArray(w * h) { if (it % w < 4) 0f else 255f }
        val m = EdgeMath.sobel(g, w, h)
        assertTrue(m[3 * w + 3] > 0.9f)
        assertEquals(0f, m[3 * w + 1], 0.0001f)
    }

    @Test
    fun grayOfWhiteIsAbout255() {
        val g = EdgeMath.gray(intArrayOf(0xFFFFFFFF.toInt()))
        assertEquals(255f, g[0], 0.5f)
    }
}
